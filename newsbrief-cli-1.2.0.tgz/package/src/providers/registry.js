// Providers that speak the OpenAI-style /chat/completions API.
// Defaults can always be overridden with --model / --base-url / NEWSBRIEF_MODEL.
const OPENAI_COMPAT = {
  openai:     { baseUrl: "https://api.openai.com/v1",      model: "gpt-4o-mini" },
  openrouter: { baseUrl: "https://openrouter.ai/api/v1",   model: "openai/gpt-4o-mini" },
  groq:       { baseUrl: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile" },
  perplexity: { baseUrl: "https://api.perplexity.ai",      model: "sonar" },
  xai:        { baseUrl: "https://api.x.ai/v1",            model: "grok-3-mini" },
  deepseek:   { baseUrl: "https://api.deepseek.com/v1",    model: "deepseek-chat" },
  mistral:    { baseUrl: "https://api.mistral.ai/v1",      model: "mistral-small-latest" },
  together:   { baseUrl: "https://api.together.xyz/v1",    model: "meta-llama/Llama-3.3-70B-Instruct-Turbo" },
  custom:     {}, // any OpenAI-compatible endpoint (Ollama, LM Studio, vLLM, ...)
};

const ENV_KEYS = {
  anthropic: ["ANTHROPIC_API_KEY"],
  gemini: ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
  openai: ["OPENAI_API_KEY"],
  openrouter: ["OPENROUTER_API_KEY"],
  groq: ["GROQ_API_KEY"],
  perplexity: ["PERPLEXITY_API_KEY"],
  xai: ["XAI_API_KEY"],
  deepseek: ["DEEPSEEK_API_KEY"],
  mistral: ["MISTRAL_API_KEY"],
  together: ["TOGETHER_API_KEY"],
  custom: ["NEWSBRIEF_API_KEY"],
};

const PROVIDERS = Object.keys(ENV_KEYS);

// Guess the provider from the key's format. Returns null if unsure.
function detectProvider(key) {
  if (!key) return null;
  if (key.startsWith("sk-ant-")) return "anthropic";
  if (key.startsWith("AQ.") || key.startsWith("AIza")) return "gemini";
  if (key.startsWith("sk-or-")) return "openrouter";
  if (key.startsWith("gsk_")) return "groq";
  if (key.startsWith("pplx-")) return "perplexity";
  if (key.startsWith("xai-")) return "xai";
  if (key.startsWith("sk-")) return "openai";
  return null;
}

module.exports = { OPENAI_COMPAT, ENV_KEYS, PROVIDERS, detectProvider };

const { buildHeadlinesPrompt, parseItems } = require("../prompt");

async function fetchWithOpenAICompat(genre, headlines, { provider, key, baseUrl, model }) {
  if (!baseUrl || !model) {
    throw new Error("This provider needs a base URL and model. Use --base-url and --model (or run `newsbrief --reset-key` and set up again).");
  }
  const url = baseUrl.replace(/\/+$/, "") + "/chat/completions";

  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: buildHeadlinesPrompt(genre, headlines) }],
      }),
    });
  } catch {
    throw new Error(`Couldn't reach ${baseUrl}. Check the URL and your connection.`);
  }

  if (!res.ok) {
    let detail = "";
    try {
      const j = await res.json();
      detail = j.error?.message || j.message || "";
    } catch {}
    if (res.status === 401 || res.status === 403) {
      throw new Error(
        `${provider} rejected the API key (${detail || res.status}). If this key belongs to another provider, run \`newsbrief --reset-key\`, then \`newsbrief --provider <name>\`.`
      );
    }
    if (res.status === 404 || /model/i.test(detail)) {
      throw new Error(`Model "${model}" isn't available for this key (${detail || res.status}). Pick another with --model <name>.`);
    }
    if (res.status === 429) throw new Error("Rate limit or quota hit. Wait a minute and try again.");
    throw new Error(`${provider} API error ${res.status}: ${detail}`);
  }

  const data = await res.json();
  let text = data.choices?.[0]?.message?.content;
  if (Array.isArray(text)) text = text.map((p) => p.text || "").join("");
  if (!text) throw new Error("The model returned an empty response. Try again.");
  return parseItems(text);
}

module.exports = { fetchWithOpenAICompat };

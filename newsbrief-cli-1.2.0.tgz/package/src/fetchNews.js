const { fetchWithAnthropic } = require("./providers/anthropic");
const { fetchWithGemini } = require("./providers/gemini");
const { fetchWithOpenAICompat } = require("./providers/openai");
const { fetchHeadlines } = require("./rss");

async function fetchNews(genre, creds) {
  const { provider, key, model } = creds;

  // These two have built-in live web search.
  if (provider === "gemini") return fetchWithGemini(genre, key, model);
  if (provider === "anthropic") return fetchWithAnthropic(genre, key, model);

  // Everyone else: fetch fresh headlines, let the model rank and summarise them.
  const headlines = await fetchHeadlines(genre);
  if (!headlines.length) return [];
  return fetchWithOpenAICompat(genre, headlines, creds);
}

module.exports = { fetchNews };

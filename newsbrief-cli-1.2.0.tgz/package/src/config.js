const fs = require("fs");
const os = require("os");
const path = require("path");
const { OPENAI_COMPAT, ENV_KEYS, PROVIDERS, detectProvider } = require("./providers/registry");

const DIR = path.join(os.homedir(), ".newsbrief");
const FILE = path.join(DIR, "config.json");

function load() {
  try {
    return JSON.parse(fs.readFileSync(FILE, "utf8"));
  } catch {
    return {};
  }
}

function save(data) {
  fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2), { mode: 0o600 });
}

const fromEnv = (p) => (ENV_KEYS[p] || []).map((n) => process.env[n]).find(Boolean);

// Returns { provider, key, baseUrl, model } or null. Env vars win over the saved key.
function getCredentials(forced) {
  const cfg = load();
  const saved = cfg.provider || detectProvider(cfg.apiKey);

  const make = (provider, key) => {
    const reg = OPENAI_COMPAT[provider] || {};
    const mine = saved === provider;
    return {
      provider,
      key,
      baseUrl: process.env.NEWSBRIEF_BASE_URL || (mine && cfg.baseUrl) || reg.baseUrl,
      model: process.env.NEWSBRIEF_MODEL || (mine && cfg.model) || reg.model,
    };
  };

  if (forced) {
    const key = fromEnv(forced) || (saved === forced ? cfg.apiKey : null);
    return key ? make(forced, key) : null;
  }
  for (const p of PROVIDERS) {
    const k = fromEnv(p);
    if (k) return make(p, k);
  }
  if (cfg.apiKey && saved) return make(saved, cfg.apiKey);
  return null;
}

function setCredentials(provider, apiKey, extra = {}) {
  save({ provider, apiKey, ...extra });
}

function clearApiKey() {
  save({});
}

module.exports = { getCredentials, setCredentials, clearApiKey, detectProvider, PROVIDERS, FILE };

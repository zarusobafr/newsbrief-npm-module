// Free, keyless headline source: Google News RSS search, limited to the last day.
const decode = (s) =>
  s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, "&")
    .trim();

const tag = (block, name) => {
  const m = block.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`));
  return m ? decode(m[1]) : "";
};

function feedUrl(genre) {
  const region = (process.env.NEWSBRIEF_REGION || "US").toUpperCase();
  const q = encodeURIComponent(`${genre} when:1d`);
  return `https://news.google.com/rss/search?q=${q}&hl=en-${region}&gl=${region}&ceid=${region}:en`;
}

function parseFeed(xml, now = Date.now()) {
  const seen = new Set();
  const out = [];
  for (const m of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const block = m[1];
    const source = tag(block, "source");
    let title = tag(block, "title");
    if (source && title.endsWith(` - ${source}`)) title = title.slice(0, -(source.length + 3));
    if (!title) continue;

    const t = Date.parse(tag(block, "pubDate"));
    const ageHours = Number.isNaN(t) ? null : Math.max(0, Math.round((now - t) / 36e5));
    if (ageHours != null && ageHours > 26) continue; // keep it to the last day

    const k = title.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push({ title, source, ageHours });
    if (out.length >= 40) break;
  }
  return out;
}

async function fetchHeadlines(genre) {
  let res;
  try {
    res = await fetch(feedUrl(genre), {
      headers: { "user-agent": "Mozilla/5.0 (newsbrief-cli)" },
      signal: AbortSignal.timeout(15000),
    });
  } catch {
    throw new Error("Couldn't reach Google News. Check your internet connection and try again.");
  }
  if (!res.ok) throw new Error(`Google News returned ${res.status}. Try again in a moment.`);
  return parseFeed(await res.text());
}

module.exports = { fetchHeadlines, parseFeed, feedUrl };
